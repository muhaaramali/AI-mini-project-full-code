import cv2
import mediapipe as mp
import webbrowser
import time
from datetime import datetime, timezone, timedelta
from subprocess import call
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles
mp_hands = mp.solutions.hands

# Function to get the current time in Sri Lanka


import requests

# current Weather of killinochi
def get_weather(api_key, city):
    base_url = "http://api.openweathermap.org/data/2.5/weather"
    params = {
        "q": city,
        "appid": api_key,
        "units": "metric"  # You can change to "imperial" for Fahrenheit
    }

    response = requests.get(base_url, params=params)

    if response.status_code == 200:
        data = response.json()
        return data
    else:
        print(f"Error: {response.status_code}")
        return None

# Replace 'your_api_key' with your actual OpenWeatherMap API key
api_key = '75153dbc82856017c443cf13a933a5a1'
city = 'Kilinochchi, LK'  # Specify the city and country code with ISO country code

# Retrieve weather data
weather_data = get_weather(api_key, city)

#Sri lankan Current Time
def get_sri_lanka_time():
    # Set the time zone for Sri Lanka
    sri_lanka_timezone = timezone(timedelta(hours=5, minutes=30))  # UTC+5:30

    # Get the current UTC time
    utc_now = datetime.utcnow()

    # Convert to Sri Lanka time
    sri_lanka_time = utc_now.replace(tzinfo=timezone.utc).astimezone(sri_lanka_timezone)

    return sri_lanka_time

# Open Wikipedia Page
def open_wikipedia_page(title):
  # Construct the URL for the Wikipedia page
  wikipedia_url = f"https://en.wikipedia.org/wiki/{title}"

  # Open the Wikipedia page in the default web browser
  webbrowser.open(wikipedia_url)

  # Function to open a YouTube page in the default web browser




# For webcam input:
cap = cv2.VideoCapture(0)
with mp_hands.Hands(
    model_complexity=0,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5) as hands:
  while cap.isOpened():
    success, image = cap.read()
    if not success:
      print("Ignoring empty camera frame.")
      # If loading a video, use 'break' instead of 'continue'.
      continue

    # To improve performance, optionally mark the image as not writeable to
    # pass by reference.
    image.flags.writeable = False
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    results = hands.process(image)

    # Draw the hand annotations on the image.
    image.flags.writeable = True
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)

    # Initially set finger count to 0 for each cap
    fingerCount = 0



    if results.multi_hand_landmarks:

      for hand_landmarks in results.multi_hand_landmarks:
        # Get hand index to check label (left or right)
        handIndex = results.multi_hand_landmarks.index(hand_landmarks)
        handLabel = results.multi_handedness[handIndex].classification[0].label

        # Set variable to keep landmarks positions (x and y)
        handLandmarks = []

        # Fill list with x and y positions of each landmark
        for landmarks in hand_landmarks.landmark:
          handLandmarks.append([landmarks.x, landmarks.y])

        # Test conditions for each finger: Count is increased if finger is
        #   considered raised.
        # Thumb: TIP x position must be greater or lower than IP x position,
        #   deppeding on hand label.
        if handLabel == "Left" and handLandmarks[4][0] > handLandmarks[3][0]:
          fingerCount = fingerCount+1
        elif handLabel == "Right" and handLandmarks[4][0] < handLandmarks[3][0]:
          fingerCount = fingerCount+1

        # Other fingers: TIP y position must be lower than PIP y position,
        #   as image origin is in the upper left corner.
        if handLandmarks[8][1] < handLandmarks[6][1]:       #Index finger
          fingerCount = fingerCount+1
        if handLandmarks[12][1] < handLandmarks[10][1]:     #Middle finger
          fingerCount = fingerCount+1
        if handLandmarks[16][1] < handLandmarks[14][1]:     #Ring finger
          fingerCount = fingerCount+1
        if handLandmarks[20][1] < handLandmarks[18][1]:     #Pinky
          fingerCount = fingerCount+1

        # Draw hand landmarks
        mp_drawing.draw_landmarks(
            image,
            hand_landmarks,
            mp_hands.HAND_CONNECTIONS,
            mp_drawing_styles.get_default_hand_landmarks_style(),
            mp_drawing_styles.get_default_hand_connections_style())

    # Display finger count
   # cv2.putText(image, str(fingerCount), (50, 450), cv2.FONT_HERSHEY_SIMPLEX, 3, (255, 0, 0), 10)
        # Display finger count in the output terminal
        if fingerCount == 0:
            print("hi")
        if fingerCount == 1:
            current_time_in_sri_lanka = get_sri_lanka_time()
            print("Current time in Sri Lanka:", current_time_in_sri_lanka)
        if fingerCount == 2:
            def open_py_file():
                call(["python", "chatgpt.py"])
        if fingerCount == 3:
            open_wikipedia_page("Main_Page")
        if fingerCount == 4:
          if weather_data:
            temperature = weather_data['main']['temp']
            description = weather_data['weather'][0]['description']
            print(f"Current weather in {city}: {temperature}°C, {description}")
          else:
            print("Unable to fetch weather data.")
        if fingerCount == 5:
            from subprocess import call
            def open_py_file():
                call(["python", "chatgpt.py"])
            open_py_file()
        if fingerCount == 6:
            def open_py_file():
                call(["python", "hand_drawing.py"])
                open_py_file()
        if fingerCount == 7:
            # Define the URL you want to open
            url_youtube = "https://www.youtube.com/"
            # Open the URL in the default web browser
            webbrowser.open(url_youtube)
        if fingerCount == 8:
            def open_py_file():
                call(["python", "calculator_interface.py"])
                open_py_file()
        if fingerCount == 9:
            def open_py_file():
                call(["python", "phonecall.py"])
                open_py_file()
        if fingerCount == 10:
            def open_py_file():
                call(["python", "calculator_interface.py"])
                open_py_file()
    # Assuming you want to introduce a delay of 500 milliseconds
    delay_in_milliseconds = 1000 / 1000  # Convert milliseconds to seconds
    time.sleep(delay_in_milliseconds)
    # Display image
    cv2.imshow('MediaPipe Hands', image)
    if cv2.waitKey(5) & 0xFF == 27:
      break
cap.release()