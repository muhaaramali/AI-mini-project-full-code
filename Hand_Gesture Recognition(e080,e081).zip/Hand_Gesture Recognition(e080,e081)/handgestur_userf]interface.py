import tkinter as tk
import cv2
import numpy as np

def on_button_click():
    label.config(text="Hello, " + entry.get())

# OpenCV setup
cap = cv2.VideoCapture(0)  # Use the default camera
hand_cascade = cv2.CascadeClassifier('path/to/your/hand_cascade.xml')

def detect_hand(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    hands = hand_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    if len(hands) > 0:
        return True
    else:
        return False

# Tkinter setup
root = tk.Tk()
root.title("Hand Gesture Interface")

label = tk.Label(root, text="Enter your name:")
label.pack()

entry = tk.Entry(root)
entry.pack()

button = tk.Button(root, text="Say Hello", command=on_button_click)
button.pack()

# Start the main event loop
while True:
    ret, frame = cap.read()

    if detect_hand(frame):
        on_button_click()

    cv2.imshow('Hand Gesture Recognition', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
root.mainloop()
