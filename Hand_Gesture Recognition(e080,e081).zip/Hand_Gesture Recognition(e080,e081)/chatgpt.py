import openai, pyttsx3
def Cgpt():
    text_speech = pyttsx3.init()
    # Add your API key here securely (without directly exposing it in code)
    api_key = "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"

    # Set the API key
    openai.api_key = api_key
    # Set up the prompt and call the API
    model_engine = "text-davinci-003"
    prompt = input("How can I assist you?")


    completion = openai.completions.create(
        model="gpt-3.5-turbo-instruct",
        prompt=prompt,
        stop=None,
        n=1,
        max_tokens=1024,
        temperature=0.5,
    )
    if completion and completion.choices:
        response = completion.choices[0].text
        print(response)
        text_speech.say(response)
        text_speech.runAndWait()
    else:
        print("Empty or invalid response received.")
        text_speech.say("Empty or invalid response received.")
        text_speech.runAndWait()
Cgpt()