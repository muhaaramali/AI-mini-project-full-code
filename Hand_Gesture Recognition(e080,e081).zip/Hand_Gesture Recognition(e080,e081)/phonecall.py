class SMSMock(object):
    def __init__(self):
        pass

    def makeCall(self, phoneNumber):
        """
        Simulate making a phone call.
        """
        print("Simulating a phone call to {}".format(phoneNumber))
        return True

if __name__ == "__main__":
    sim = SMSMock()

    # Take phone number as input from the user
    phone_number_to_call = input("Enter the phone number to call: ")

    if sim.makeCall(phone_number_to_call):
        print("Simulated phone call initiated to {}".format(phone_number_to_call))
    else:
        print("Failed to initiate the simulated phone call.")
